# coding: utf-8

# flake8: noqa
from __future__ import absolute_import
# import models into model package
from swagger_server.models.inline_response200 import InlineResponse200
from swagger_server.models.request_institution_add import RequestInstitutionAdd
from swagger_server.models.request_institution_upd import RequestInstitutionUpd
from swagger_server.models.response400 import Response400
from swagger_server.models.response_institution import ResponseInstitution
from swagger_server.models.response_institution_data import ResponseInstitutionData
